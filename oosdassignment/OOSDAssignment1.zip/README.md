# OOSDAssignment

Team Name: The High Distinctions

Participants Name & IDs:

	Liam Scanlon	3727321
	Shajie Chen		3582098
	Sheng Kai Chen	3523185
	Priyanga Dilip	3670781

Make sure JDK 9.0.4 is installed.

Attached documents:
	OOSD Diagrams.pdf
	OOSD Presentation.pdf

src\ Contains Eclipse source code.
doc\ Contains Java Documentation
img\ Contains icon images for use in game.