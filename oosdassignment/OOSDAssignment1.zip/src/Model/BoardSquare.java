package Model;

public interface BoardSquare {

	public static enum Type {
		NONE, OBSTACLE, MERCHANT, GUARD, PIKEMAN, ASSASSIN, WIZARD, KNIGHT
	}

	public Type getType();

	public int getPositionX();

	public int getPositionY();
}
