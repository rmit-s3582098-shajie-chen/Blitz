package Model;

import com.google.java.contract.Ensures;
import com.google.java.contract.Invariant;
import com.google.java.contract.Requires;

/**
 * (MVC) Manages the core data of the application, also wraps the Game/Board.
 */
@Invariant({ "game != null", "instance != null" })
public class Model {
	private Game game = new Game();
	private static Model instance;

	// ...
	@Ensures({ "result != null " })
	public static Model getInstance() {
		if (instance == null) {
			instance = new Model();
		}
		return instance;
	}

	@Requires({ "startx > 0", "starty > 0", "ednx > 0", "endy >0 ", "startx  < width ", "starty < height",
			"endx < width ", "endy < height" })
	public boolean isValidMove(int startx, int starty, int endx, int endy) {
		return game.testValidMove(startx, starty, endx, endy);
	}

	@Requires({ "startx > 0", "starty > 0", "endx > 0", "endy >0 ", "startx  < width ", "starty < height",
		"endx < width ", "endy < height", "(startx != endx) && (starty != endy)" })
	public boolean makeMove(int startx, int starty, int endx, int endy) {
		return game.move(startx, starty, endx, endy);
	}

	public int getNumMoves() {
		return game.getNumMoves();
	}

	public String getCurrentPlayer() {
		return game.getCurrentPlayer();
	}

	public void switchPlayer() {
		game.switchPlayer();
	}

	public int getHeight() {
		return game.getHeight();
	}

	public int getWidth() {
		return game.getWidth();
	}

	@Requires({ "x > 0", "y > 0" })
	@Ensures({ "result != null" })
	public BoardSquare.Type getPieceType(int x, int y) {
		return game.getPieceType(x, y);
	}

	public void startGame(int size) {
		game.startGame(size);
	}

}
