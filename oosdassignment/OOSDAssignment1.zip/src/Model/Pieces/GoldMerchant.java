package Model.Pieces;

import Model.Piece;

/**
 * Role of the goldMerchant is to be brought to the top of the board.
 */
public class GoldMerchant extends Piece {

	public GoldMerchant() {
		type = Type.MERCHANT;
		moveDistance = 2;
		power = 0;
	}

}
