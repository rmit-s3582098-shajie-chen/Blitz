package Model.Pieces;

import Model.Piece;

public class Guard extends Piece { 
	
	public Guard() {
		type = Type.GUARD;
		moveDistance = 3;
		power = 1 ; 
	}
}
