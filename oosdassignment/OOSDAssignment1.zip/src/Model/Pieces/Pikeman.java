package Model.Pieces;

import Model.Piece;

public class Pikeman extends Piece { 
	
	public Pikeman() {
		type = Type.PIKEMAN;
		moveDistance = 2;
		power = 3 ; 
	}
}
