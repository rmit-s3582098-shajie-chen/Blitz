package Model.Pieces;

import Model.Piece;

public class Wizard extends Piece {

	public Wizard() {
		type = Type.WIZARD;
		moveDistance = 2;
		power = 2 ; 
	}
}
