package Model.Pieces;

import Model.Piece;

public class Assassin extends Piece {

	public Assassin() {
		type = Type.ASSASSIN;
		moveDistance = 4;
		power = 0;
	}
}