package Model.Pieces;

import Model.Piece;

public class Knight extends Piece {

	public Knight() {
		type = Type.KNIGHT;
		moveDistance = 3;
		power = 3;
	}
}
