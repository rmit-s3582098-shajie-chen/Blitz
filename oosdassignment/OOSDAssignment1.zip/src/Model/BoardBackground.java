package Model;

import com.google.java.contract.Ensures;

public enum BoardBackground implements BoardSquare {
	OBSTACLE(8362), EMPTY(0);

	protected Type type;

	@Ensures({ "type != null" })
	private BoardBackground(final int charNum) {
		if (charNum != 0) {
			type = Type.OBSTACLE;
		} else
			type = Type.NONE;
	}

	@Override
	public Type getType() {
		return type;
	}

	@Override
	public int getPositionX() {
		// Unimplemented, will complete in Assignment 2.
		return 0;
	}

	@Override
	public int getPositionY() {
		// Unimplemented, will complete in Assignment 2.
		return 0;
	}
}
