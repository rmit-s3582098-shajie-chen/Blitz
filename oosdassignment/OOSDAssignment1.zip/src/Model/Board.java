package Model;

import java.util.ArrayList;
import java.util.List;

import com.google.java.contract.Ensures;
import com.google.java.contract.Invariant;
import com.google.java.contract.Requires;

import Model.BoardSquare.Type;
import Model.Pieces.Assassin;
import Model.Pieces.GoldMerchant;
import Model.Pieces.Guard;
import Model.Pieces.Knight;
import Model.Pieces.Pikeman;
import Model.Pieces.Wizard;

@Invariant({ "unitCollection != null" })
public class Board {
	// Declare 2D array list
	List<List<BoardSquare>> unitCollection;
	private int height;
	private int width;

	public Board(int h, int w) {
		height = h;
		width = w;
		unitCollection = initializeBoard(width, height);
	}

	/**
	 * Creates a board, generating pieces and the background.
	 * 
	 * @param width
	 *            Desired width of the board (in cells).
	 * @param height
	 *            Desired height of the board (in cells).
	 * @return The generated board.
	 */
	@Requires({ "width > 0", "height > 0" })
	@Ensures({ "unitCollection != null" })
	private List<List<BoardSquare>> initializeBoard(int width, int height) {
		// Create 2D array list
		unitCollection = new ArrayList<List<BoardSquare>>(height);
		// Default unit
		BoardSquare boardSquare;
		for (int h = 1; h <= height; h++) {
			List<BoardSquare> row = new ArrayList<BoardSquare>();
			for (int w = 1; w <= width; w++) {
				if ((h == 1 && w == 1) || (h == 1 && w == 2) || (h == 1 && w == height - 1) || (h == 1 && w == height)
						|| (h == 2 && w == 1) || (h == 2 && w == height) || (h == height - 1 && w == 1)
						|| (h == height - 1 && w == height) || (h == height && w == 1) || (h == height && w == 2)
						|| (h == height && w == height - 1) || (h == height && w == height)) {
					boardSquare = BoardBackground.OBSTACLE;
				} else if (h == height && w == (width / 2) + 1) {
					boardSquare = new GoldMerchant();
				} else if (h == height - 1 && w == width / 2) {
					boardSquare = new Pikeman();
				} else if (h == height - 1 && w == width / 2 + 2) {
					boardSquare = new Pikeman();
				} else if (h == height - 1 && w == width / 2 - 1) {
					boardSquare = new Guard();
				} else if (h == height - 1 && w == width / 2 + 3) {
					boardSquare = new Guard();
				} else if (h == 1 && w == (width / 2) + 1) {
					boardSquare = new Wizard();
				} else if (h == 2 && w == width / 2) {
					boardSquare = new Knight();
				} else if (h == 2 && w == width / 2 + 2) {
					boardSquare = new Knight();
				} else if (h == 2 && w == width / 2 - 1) {
					boardSquare = new Assassin();
				} else if (h == 2 && w == width / 2 + 3) {
					boardSquare = new Assassin();
				} else
					boardSquare = BoardBackground.EMPTY;

				if (boardSquare instanceof Piece) {
					((Piece) boardSquare).setPosition(w - 1, h - 1);
				}

				row.add(boardSquare);
			}
			unitCollection.add(row);
		}
		return unitCollection;
	}

	public int getHeight() {
		return height;
	}

	@Requires("h > 0")
	@Ensures("height == h")
	public void setHeight(int h) {
		this.height = h;
	}

	@Requires("w > 0")
	@Ensures("width == w")
	public void setWidth(int w) {
		this.width = w;
	}

	public int getWidth() {
		return width;
	}

	@Requires({ "x > 0", "y > 0", "x < width", "y < height" })
	@Ensures({ "unitCollection.get(y).get(x).getType() !=null" })
	public Piece.Type getPieceType(int x, int y) {
		return unitCollection.get(y).get(x).getType();
	}

	@Requires({ "x > 0", "y > 0", "x < width", "y < height" })
	@Ensures({ "unitCollection.get(y).get(x) !=null" })
	public BoardSquare getUnit(int x, int y) {
		return unitCollection.get(y).get(x);
	}

	@Requires({ "startx > 0", "starty > 0", "endx > 0", "endy >0 ", "startx  < width ", "starty < height",
			"endx < width ", "endy < height" })
	public void move(int startx, int starty, int endx, int endy) {
		BoardSquare unit = unitCollection.get(starty).get(startx);
		((Piece) unit).setPosition(endx, endy);

		unitCollection.get(endy).set(endx, unit);
		unitCollection.get(starty).set(startx, BoardBackground.EMPTY);
	}

	/**
	 * Finds out whether the specified unit exists on the board.
	 * 
	 * @param unitType
	 *            Specified unit type.
	 * @return True, if the unit exists.
	 */
	@Requires({ "unitType != null" })
	public boolean existingUnit(Type unitType) {
		for (List<BoardSquare> list : unitCollection) {
			for (BoardSquare unit : list) {
				if (unit.getType().equals(unitType)) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Searches for the BoardSquare where the specified unit is.
	 * 
	 * @param unitType
	 *            The type of specified unit.
	 * @return The BoardSquare where the unit is.
	 */
	@Requires({ "unitType != null" })
	public BoardSquare searchUnit(Type unitType) {
		for (List<BoardSquare> list : unitCollection) {
			for (BoardSquare unit : list) {
				if (unit.getType().equals(unitType)) {
					return unit;
				}
			}
		}
		return null;
	}
}
