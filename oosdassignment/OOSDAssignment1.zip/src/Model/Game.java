package Model;

import com.google.java.contract.Ensures;
import com.google.java.contract.Invariant;
import com.google.java.contract.Requires;

import Controller.Controller;
import Model.BoardSquare.Type;

@Invariant({ "gameBoard != null", "currentTurn != null", "numMoves >= 0" })
public class Game {
	private Board gameBoard;
	private int numMoves = 0;
	private Turn currentTurn;

	private enum Turn {
		MerchantTeam("Merchant Team"), BanditTeam("Bandit Team");
		private final String text;

		Turn(final String text) {
			this.text = text;
		}

		@Override
		public String toString() {
			return text;
		}

		/**
		 * Finds which team the specified piece belongs to.
		 * @param type Type of piece.
		 * @return Team (Merchant, or Bandit)
		 */
		public Turn testTheUnitBelongs(Type type) {
			if (type == Piece.Type.MERCHANT || type == Piece.Type.GUARD || type == Piece.Type.PIKEMAN) {
				return Turn.MerchantTeam;
			} else if (type == Piece.Type.KNIGHT || type == Piece.Type.WIZARD || type == Piece.Type.ASSASSIN) {
				return Turn.BanditTeam;
			}
			return null;
		}
	};

	public Game() {
		currentTurn = Turn.MerchantTeam;
	}

	/**
	 * Switches the current player without making a move. Used when the move timer
	 * runs out.
	 */
	public void switchPlayer() {
		if (currentTurn == Turn.MerchantTeam) {
			currentTurn = Turn.BanditTeam;
		} else {
			currentTurn = Turn.MerchantTeam;
		}
	}

	/**
	 * Test to see whether the specified move can take place.
	 * 
	 * @param startX
	 *            Y location of the unit to move.
	 * @param startY
	 *            X location of the unit to move.
	 * @param endX
	 *            X location of where the place the unit.
	 * @param endY
	 *            Y location of where the place the unit.
	 * @return True, if the move is a valid one.
	 */
	@Requires({ "startx > 0", "starty > 0", "ednx > 0", "endy >0 ", "startx  < width ", "starty < height",
			"endx < width ", "endy < height" })
	public boolean testValidMove(int startX, int startY, int endX, int endY) {
		Piece.Type type = gameBoard.getPieceType(startX, startY);

		if (type != Piece.Type.NONE) {
			if (currentTurn.testTheUnitBelongs(type) == currentTurn) {
				if (((Piece) gameBoard.getUnit(startX, startY)).canMoveHere(endX, endY)) {
					Piece.Type destinationType = gameBoard.getPieceType(endX, endY);
					if (currentTurn.testTheUnitBelongs(destinationType) != currentTurn) {
						return true;
					}
				}
			}
		}
		return false;
	}

	/**
	 * Moves the unit at (startx, starty) to (endx, endy)
	 * 
	 * @param startx
	 *            Y location of the unit to move.
	 * @param starty
	 *            X location of the unit to move.
	 * @param endx
	 *            X location of where the place the unit.
	 * @param endy
	 *            Y location of where the place the unit.
	 * @return True, if the move was successful.
	 */
	@Requires({ "startx > 0", "starty > 0", "endx > 0", "endy >0 ", "startx  < width ", "starty < height",
			"endx < width ", "endy < height", "(startx != endx) && (starty != endy)", "endx < width ",
			"endy < height" })
	public boolean move(int startx, int starty, int endx, int endy) {
		if (testValidMove(startx, starty, endx, endy)) {
			System.out.println("Move " + startx + " " + starty + " to " + endx + " " + endy);
			gameBoard.move(startx, starty, endx, endy);
			numMoves++;
			/* check whether the goldMerchant existing or not */
			hasTheGameEnded(Type.MERCHANT);
			/* update current turn */
			if (currentTurn == Turn.MerchantTeam) {
				currentTurn = Turn.BanditTeam;
			} else {
				currentTurn = Turn.MerchantTeam;
			}
			System.out.println("Current turn is  " + currentTurn.toString());
			return true;
		}
		return false;
	}

	/**
	 * Checks the board status to see whether the game has ended. Looks at whether
	 * the merchant still exists, and if it does, checks if it has reached the top
	 * of the board.
	 * 
	 * @param unitType Unit type to check.
	 * @return True, if the game has ended.
	 */
	@Requires({ "unitType != null" })
	public boolean hasTheGameEnded(Type unitType) {
		if (gameBoard.existingUnit(unitType) == false) {
			System.out.println(String.format("The winner is %s", getCurrentPlayer()));
			Controller.getInstance().exitGame();
			return true;
		} else {
			if (gameBoard.searchUnit(unitType).getPositionY() == 0) {
				System.out.println(String.format("The winner is %s", getCurrentPlayer()));
				Controller.getInstance().exitGame();
				return true;
			}
		}
		return false;
	}

	public String getCurrentPlayer() {
		return currentTurn.toString();
	}

	public int getNumMoves() {
		return numMoves;
	}

	public int getHeight() {
		return gameBoard.getHeight();
	}

	public int getWidth() {
		return gameBoard.getWidth();
	}

	@Requires({ "x > 0", "y > 0", "x < gameBoard.getWidth()", "y < gameBoard.getHeight()" })
	public BoardSquare.Type getPieceType(int x, int y) {
		return gameBoard.getPieceType(x, y);
	}

	@Ensures({ "gameBoard != null" })
	public void startGame(int size) {
		gameBoard = new Board(size, size);
		numMoves = 0;
	}

}
