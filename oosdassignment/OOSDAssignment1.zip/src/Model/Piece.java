package Model;

import com.google.java.contract.Ensures;
import com.google.java.contract.Requires;

public abstract class Piece implements BoardSquare {
	protected Type type = Type.NONE;
	protected int moveDistance = 0;
	protected int power = 1;
	private int x = -1;
	private int y = -1;

	public Type getType() {
		return type;
	}

	/**
	 * Tells us whether this unit could reach the specified location in one move.
	 * @param x X location.
	 * @param y Y location.
	 * @return True, if the unit can reach.
	 */
	@Requires({ "x > 0", "y > 0" })
	public boolean canMoveHere(int x, int y) {
		int manhattanDistance = Math.abs(this.x - x) + Math.abs(this.y - y);
		return (manhattanDistance <= moveDistance);
	}

	@Requires({ "x > 0", "y > 0" })
	@Ensures({ "this.x = x", "this.y = y" })
	public void setPosition(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public int getPositionX() {
		return x;
	}

	public int getPositionY() {
		return y;
	}
}
