package View;

import java.io.File;
import java.util.ArrayList;

import javafx.scene.Scene;
import javafx.scene.image.Image;

public abstract class Window {

	public enum TileType {
		BLANK(0), ASSASSIN(1), MERCHANT(2), KNIGHT(3), WIZARD(4), PIKEMAN(5), GUARD(6);

		private final int value;

		private TileType(int value) {
			this.value = value;
		}

		public int getValue() {
			return value;
		}
	}

	protected ArrayList<Image> unselectedTiles = new ArrayList<Image>();
	protected ArrayList<Image> selectedTiles = new ArrayList<Image>();

	/**
	 * Loads icon images into an ArrayList for later use by subclasses.
	 */
	protected void loadImages() {
		File file = new File("img/blank.png");
		unselectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/assassin.png");
		unselectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/merchant.png");
		unselectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/knight.png");
		unselectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/wizard.png");
		unselectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/pikeman.png");
		unselectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/guard.png");
		unselectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/available.png");
		selectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/assassinSelected.png");
		selectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/merchantSelected.png");
		selectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/knightSelected.png");
		selectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/wizardSelected.png");
		selectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/pikemanSelected.png");
		selectedTiles.add(new Image(file.toURI().toString()));
		file = new File("img/guardSelected.png");
		selectedTiles.add(new Image(file.toURI().toString()));
	}

	/**
	 * Generates a scene depending on which (concrete) window class it is.
	 * 
	 * @return The Scene to display.
	 */
	protected abstract Scene generateScene();
}
