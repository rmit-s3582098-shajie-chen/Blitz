package View;

import Controller.Controller;
import Model.BoardSquare;
import Model.Model;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.util.Duration;

public class GameWindow extends Window {

	private int xSelected = -1;
	private int ySelected = -1;
	private long previousMoveTime = 0;
	private StringProperty timeLeft = new SimpleStringProperty();
	private int timerTotal = 30;

	public GameWindow() {
		loadImages();
	}

	@Override
	protected Scene generateScene() {
		// Set the grid layout
		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(0);
		grid.setVgap(0);
		grid.setPadding(new Insets(25, 25, 25, 25));

		Model model = Model.getInstance();

		// For each BoardSquare in the grid of the board, we place an image, and add a
		// mouse click event handler.
		for (int x = 0; x < model.getWidth(); x++) {
			for (int y = 0; y < model.getHeight(); y++) {

				boolean showSelected = false;

				if (xSelected >= 0 && ySelected >= 0) {
					if (x == xSelected && y == ySelected || model.isValidMove(xSelected, ySelected, x, y)) {
						showSelected = true;
					}
				}

				Image image = getPieceImage(model.getPieceType(x, y), showSelected);
				final ImageView imageView = new ImageView();
				if (image != null) {
					imageView.setImage(image);
				}

				int xPos = x;
				int yPos = y;

				imageView.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {

					@Override
					public void handle(MouseEvent event) {

						if (xPos == xSelected && yPos == ySelected) {
							// If clicked on the same square, cancel the click.
							xSelected = -1;
							ySelected = -1;
						} else if (xSelected >= 0 && ySelected >= 0) {
							// If clicked on a different square, make a move.
							if (Controller.getInstance().makeMove(xSelected, ySelected, xPos, yPos)) {
								// Move was valid.
								previousMoveTime = System.currentTimeMillis();
							}
							xSelected = -1;
							ySelected = -1;
						} else {
							// If we haven't clicked yet, we must be selecting the piece to move.
							xSelected = xPos;
							ySelected = yPos;
						}

						View.getInstance().refreshGameWindow();
						event.consume();
					}
				});

				grid.add(imageView, x, y);
			}
		}

		// Forfeit to Menu button.
		Button btn = new Button();
		btn.setText("Forfeit to Menu");
		btn.setAlignment(Pos.CENTER);
		btn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				xSelected = -1;
				ySelected = -1;
				View.getInstance().showMainMenu();
			}
		});
		HBox hbBtn = new HBox(10);
		hbBtn.setAlignment(Pos.CENTER);
		hbBtn.getChildren().add(btn);

		// Adds the button underneath the board, with a top offset of (10).
		grid.add(hbBtn, 0, model.getHeight() + 1, model.getWidth(), 1);
		GridPane.setMargin(hbBtn, new Insets(10, 0, 0, 0));

		// Adds the current player information underneath the board, with a top offset
		// of (70).
		Label currentPlayer = new Label("Player: " + Model.getInstance().getCurrentPlayer());
		grid.add(currentPlayer, 0, model.getHeight() + 1, model.getWidth(), 1);
		GridPane.setMargin(currentPlayer, new Insets(70, 0, 0, 0));

		// Adds the number of moves information underneath the board, with a top offset
		// of (35).
		Label numMoves = new Label("Moves: " + Model.getInstance().getNumMoves());
		grid.add(numMoves, 0, model.getHeight() + 1, model.getWidth(), 1);
		GridPane.setMargin(numMoves, new Insets(35, 0, 0, 0));

		// Adds the timer information underneath the board, with a top offset of (0).
		// However the timer label is binded to the timeLeft StringProperty for
		// automatic updating.
		Label timerLabel = new Label("Timer: ");
		grid.add(timerLabel, 0, model.getHeight() + 1, model.getWidth(), 1);
		timerLabel.textProperty().bind(timeLeft);
		GridPane.setMargin(timerLabel, new Insets(0, 0, 0, 0));

		return new Scene(grid);
	}

	private Image getPieceImage(BoardSquare.Type type, boolean selected) {
		switch (type) {
		case NONE:
			return (selected) ? selectedTiles.get(TileType.BLANK.getValue())
					: unselectedTiles.get(TileType.BLANK.getValue());
		case OBSTACLE:
			break;
		case ASSASSIN:
			return (selected) ? selectedTiles.get(TileType.ASSASSIN.getValue())
					: unselectedTiles.get(TileType.ASSASSIN.getValue());
		case GUARD:
			return (selected) ? selectedTiles.get(TileType.GUARD.getValue())
					: unselectedTiles.get(TileType.GUARD.getValue());
		case KNIGHT:
			return (selected) ? selectedTiles.get(TileType.KNIGHT.getValue())
					: unselectedTiles.get(TileType.KNIGHT.getValue());
		case MERCHANT:
			return (selected) ? selectedTiles.get(TileType.MERCHANT.getValue())
					: unselectedTiles.get(TileType.MERCHANT.getValue());
		case PIKEMAN:
			return (selected) ? selectedTiles.get(TileType.PIKEMAN.getValue())
					: unselectedTiles.get(TileType.PIKEMAN.getValue());
		case WIZARD:
			return (selected) ? selectedTiles.get(TileType.WIZARD.getValue())
					: unselectedTiles.get(TileType.WIZARD.getValue());
		default:
			System.err.println("That piece type does not exist?");
			break;
		}

		return null;
	}

	public void startMoveTimer() {
		previousMoveTime = System.currentTimeMillis();
		timeLeft.set(Integer.toString(timerTotal));

		Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(0), new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				int timeElapsed = (int) ((System.currentTimeMillis() - previousMoveTime) / 1000);

				if (timeElapsed == timerTotal) {
					previousMoveTime = System.currentTimeMillis();
					Controller.getInstance().switchPlayer();
					View.getInstance().refreshGameWindow();
				}

				timeLeft.set("Timer: " + Integer.toString(timerTotal - timeElapsed));
			}
		}), new KeyFrame(Duration.seconds(1)));
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
	}

}
