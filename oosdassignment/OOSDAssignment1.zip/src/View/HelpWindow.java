package View;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;

public class HelpWindow extends Window {

	@Override
	protected Scene generateScene() {

		Text informationText = generateHelpText();
		informationText.setWrappingWidth(500);

		// Puts all the text in a centered box.
		HBox hbBtn2 = new HBox(10);
		hbBtn2.setAlignment(Pos.CENTER);
		hbBtn2.getChildren().add(informationText);

		// Back to menu button.
		Button btn = new Button();
		btn.setText("Back to Menu");
		btn.setAlignment(Pos.CENTER);
		btn.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				View.getInstance().showMainMenu();
			}
		});
		HBox hbBtn = new HBox(10);
		hbBtn.setAlignment(Pos.CENTER);
		hbBtn.getChildren().add(btn);

		// Set the grid layout
		GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(25, 25, 25, 25));
		grid.add(hbBtn2, 0, 0);
		grid.add(hbBtn, 0, 1);

		return new Scene(grid, 600, 500);
	}

	private Text generateHelpText() {
		Text informationText;
		// Various texts to help user understand the game.
		String help = new String();
		help = String.format("%s\n%s\n%s\n\n",
				"Power - Units with equal power kills each other, units with higher power will kill the unit with the weaker one.",
				"Move - How many spaces a unit can move.", "Ability - Units special ability.");
		new String();

		String merchant = String.format("%-20s-%10s-%10s\n", "Merchant", "Power(0)", "Move(2)");
		new String();
		String merchantAbility = String.format("%35s%s\n", "Ability: ", "Bring him accross the board to win");
		new String();
		String Guard = String.format("%-20s-%10s-%10s\n", "Guard", "Power(1)", "Move(3)");
		new String();
		String GuardAbility = String.format("%35s%s\n", "Ability: ", "Can take 2 hits, except from Evil Knight.");
		new String();
		String Pikeman = String.format("%-20s-%10s-%10s\n", "Pikeman ", "Power(3)", "Move(2)");
		new String();
		String PikemanAbility = String.format("%35s%s\n", "Ability: ", " Can attack 1 square away.");
		new String();
		String Assasin = String.format("%-20s-%10s-%10s\n", "Assasin ", "Power(1)", "Move(4)");
		new String();
		String AssasinAbility = String.format("%35s%s\n", "Ability: ", " Undetered movement.");
		new String();
		String Wizard = String.format("%-20s-%10s-%10s\n", "Wizard", "Power(2)", "Move(2)");
		new String();
		String WizardAbility = String.format("%35s%s\n", "Ability: ", " Can attack 1 square away.");
		new String();
		String Evil_Knight = String.format("%-20s-%10s-%10s\n", "Evil Knight ", "Power(3)", "Move(3)");
		new String();
		String Evil_KnightAbility = String.format("%35s%s\n\n", "Ability: ", " Instantly kills anything in its way.");

		new String();
		String Merchan_Team = String.format("%-20s-%10s\n", "Merchant Team",
				"You have to protect the merchant and get him to the other town to win the game. ");
		new String();
		String Merchant_Mission = String.format("%35s\n\n",
				"Defend your merchant against bandits that want to steal your goods! ");
		new String();
		String Bandit_Team = String.format("%-20s-%10s\n", "Bandit Team",
				"Stop the merchant and steal his goods before he reaches the town to win!");
		new String();
		String Bandit_Mission = String.format("%35s\n", "You lose when the merchant reaches the other town.");

		informationText = new Text(help + merchant + merchantAbility + Guard + GuardAbility + Pikeman + PikemanAbility
				+ Assasin + AssasinAbility + Wizard + WizardAbility + Evil_Knight + Evil_KnightAbility + Merchan_Team
				+ Merchant_Mission + Bandit_Team + Bandit_Mission);
		return informationText;
	}
}
