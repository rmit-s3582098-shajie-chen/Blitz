package Model.Ground;

public class GroundGrass extends Ground {

	@Override
	public Ground clone() throws CloneNotSupportedException {
		return (GroundGrass)super.clone();
	}
	
}
