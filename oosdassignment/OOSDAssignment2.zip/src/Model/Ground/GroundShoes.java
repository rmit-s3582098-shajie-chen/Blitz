package Model.Ground;

public class GroundShoes extends Ground {

	@Override
	public Ground clone() throws CloneNotSupportedException {
		return (GroundShoes)super.clone();
	}

}
