package Model.Ground;

public class GroundBlocked extends Ground {

	@Override
	public Ground clone() throws CloneNotSupportedException {
		return (GroundBlocked)super.clone();
	}

}
