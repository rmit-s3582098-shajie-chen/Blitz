package Model.Ground;

public class GroundTree extends Ground {

	@Override
	public Ground clone() throws CloneNotSupportedException {
		return (GroundTree)super.clone();
	}

}
